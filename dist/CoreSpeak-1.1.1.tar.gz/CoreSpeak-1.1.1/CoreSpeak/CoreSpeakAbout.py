from datetime import date


def about():
    dateNow = date.today()
    print("CoreSpeak is a Python library created to make your life easy with all the features of converting to text to speech.\nCoreSpeak is designed to make the most efficient out of the different python libraries and provide hem to you.\nThis module saves you from writing more than 40 ines of code. Some details about CoreSpeak are given below:")

    print("Name : CoreSpeak")
    print("Author : Sannidhya Dasgupta")
    print("Version : 1.1.1")
    print(f"Launch Date : {dateNow}")
    print("Next Version : 1.1.2")
